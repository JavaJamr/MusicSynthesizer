package com.mycompany.music_synthesizer;

import java.util.ArrayList;

public class Play {
    // Calls Piano class
    private Piano piano = new Piano();

    // Method to play a song
    public void playSong(ArrayList<Integer> toneListCh1, ArrayList<Integer> toneListCh2, ArrayList<Integer> toneListCh3, ArrayList<Integer> timeList, ArrayList<Integer> octaveList, ArrayList<Integer> Instrument1, ArrayList<Integer> Instrument2, ArrayList<Integer> Instrument3) {
        //Need three more lists XD. One for channel, one for octave, one for instruement
        for (int i = 0; i < timeList.size(); i++) {
            
            //Notes for all three channels
            int note = toneListCh1.get(i);
            int note2 = toneListCh2.get(i);
            int note3 = toneListCh3.get(i);
            
            //List of time
            int time = timeList.get(i);
            
            //Set octave of the set
            int octave=octaveList.get(i);
            
            //Set instrument for the set
            int instrument1=Instrument1.get(i);
            int instrument2=Instrument2.get(i);
            int instrument3=Instrument3.get(i);
            
            //Change the instrument with the instrument list (Default 0)
            piano.changeAllInstrument(0);
            
            //Set new instruments
            piano.changeInstrument0(instrument1);
            piano.changeInstrument1(instrument2);
            piano.changeInstrument2(instrument3);
            
            //Set silent
                int silent=12;

                //Start playing the notes of the chord as long as the notes aren't 0 (The Silent #)
                if (note!=silent){piano.unlimitedNote(note,octave,0);}
                if (note2!=silent){piano.unlimitedNote(note2,octave,1);}
                if (note3!=silent){piano.unlimitedNote(note3,octave,2);}
            
            //Stop the note after the duration
            try {Thread.sleep(time);} catch (InterruptedException e) {e.printStackTrace();}
            
            //Stops the notes if they played
            if (note!=silent){piano.stopNote(note,octave,0);}
            if (note2!=silent){piano.stopNote(note2,octave,1);}
            if (note3!=silent){piano.stopNote(note3,octave,2);}
            
            
        }
    }
}
