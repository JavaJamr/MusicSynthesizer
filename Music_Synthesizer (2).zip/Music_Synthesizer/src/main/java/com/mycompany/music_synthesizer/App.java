package com.mycompany.music_synthesizer;

import java.util.ArrayList;
import java.util.function.UnaryOperator;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.TextFormatter.Change;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import static javafx.scene.text.TextAlignment.*;

/**
 * JavaFX App
 */
import javafx.util.converter.IntegerStringConverter;
public class App extends Application {
    private final Play Play;

    public App() {
        this.Play = new Play();
    }
    
    @Override
    public void start(Stage stage) {
        //Setting up the radio button font types (bolded and normal weights)
        Font boldedFont = Font.font("Calibri",FontWeight.BOLD, 11);
        Font defaultFont = Font.font("Calibri",FontWeight.NORMAL, 11);
        //Adding ArrayLists to save the pitches of each note, the shared note lengths, and the instrument values for each note in each channel
        ArrayList<Integer> toneListCh1;
        toneListCh1 = new ArrayList<>();
        ArrayList<Integer> toneListCh2;
        toneListCh2 = new ArrayList<>();
        ArrayList<Integer> toneListCh3;
        toneListCh3 = new ArrayList<>();
        ArrayList<Integer> timeList;
        timeList = new ArrayList<>();
        ArrayList<Integer> octaveList;
        octaveList = new ArrayList<>();
        ArrayList<Integer> instrumentList1;
        instrumentList1 = new ArrayList<>();
        ArrayList<Integer> instrumentList2;
        instrumentList2 = new ArrayList<>();
        ArrayList<Integer> instrumentList3;
        instrumentList3 = new ArrayList<>();
        //ToggleGroups that will contain the letter scales of 3 notes and whether to mute a note or not.
        
        //ToggleGroup that will contain the first set of radio buttons.
            final ToggleGroup noteScale1 = new ToggleGroup();
            
        //Creating one radio button for each note in one octave and assigning each button to the toggle group.
            RadioButton radioA1 = new RadioButton("A");
            radioA1.setToggleGroup(noteScale1);
            radioA1.setFont(defaultFont);
            radioA1.setTranslateY(-120);
            
            RadioButton specialAB1 = new RadioButton("A#/Bb");
            specialAB1.setToggleGroup(noteScale1);
            specialAB1.setFont(defaultFont);
            specialAB1.setTranslateY(-100);
            
            RadioButton radioB1 = new RadioButton("B");
            radioB1.setToggleGroup(noteScale1);
            radioB1.setFont(defaultFont);
            radioB1.setTranslateY(-80);
            
            RadioButton radioC1 = new RadioButton("C");
            radioC1.setToggleGroup(noteScale1);
            /*
            Radio focuses on the C note since it's the first note of an octal scale.
            This is also the reason why the font for the C radio button is bolded.
            The same is true for the other note list radials
            */
            radioC1.requestFocus();
            radioC1.setSelected(true);
            radioC1.setFont(boldedFont);
            radioC1.setTranslateY(-60);
            
            RadioButton specialCD1 = new RadioButton("C#/Db");
            specialCD1.setToggleGroup(noteScale1);
            specialCD1.setFont(defaultFont);
            specialCD1.setTranslateY(-40);
            
            RadioButton radioD1 = new RadioButton("D");
            radioD1.setToggleGroup(noteScale1);
            radioD1.setFont(defaultFont);
            radioD1.setTranslateY(-20);
            
            RadioButton specialDE1 = new RadioButton("D#/Eb");
            specialDE1.setToggleGroup(noteScale1);
            specialDE1.setFont(defaultFont);
            specialDE1.setTranslateY(0);
            
            RadioButton radioE1 = new RadioButton("E");
            radioE1.setToggleGroup(noteScale1);
            radioE1.setFont(defaultFont);
            radioE1.setTranslateY(20);
            
            RadioButton radioF1 = new RadioButton("F");
            radioF1.setToggleGroup(noteScale1);
            radioF1.setFont(defaultFont);
            radioF1.setTranslateY(40);
            
            RadioButton specialFG1 = new RadioButton("F#/Gb");
            specialFG1.setToggleGroup(noteScale1);
            specialFG1.setFont(defaultFont);
            specialFG1.setTranslateY(60);
            
            RadioButton radioG1 = new RadioButton("G");
            radioG1.setToggleGroup(noteScale1);
            radioG1.setFont(defaultFont);
            radioG1.setTranslateY(80);
            
            RadioButton specialGA1 = new RadioButton("G#/Ab");
            specialGA1.setToggleGroup(noteScale1);
            specialGA1.setFont(defaultFont);
            specialGA1.setTranslateY(100);
            
            RadioButton silent1 = new RadioButton("Silent");
            silent1.setToggleGroup(noteScale1);
            silent1.setFont(defaultFont);
            silent1.setTranslateY(120);
            
            Group notes1 = new Group(radioA1,specialAB1,radioB1,radioC1,specialCD1,radioD1,specialDE1,radioE1,radioF1,specialFG1,radioG1,specialGA1,silent1);
            
            //Second ToggleGroup for second list of radials
            final ToggleGroup noteScale2 = new ToggleGroup();
            
            //Second radial list
            RadioButton radioA2 = new RadioButton("A");
            radioA2.setToggleGroup(noteScale2);
            radioA2.setFont(defaultFont);
            radioA2.setTranslateY(-120);
            
            RadioButton specialAB2 = new RadioButton("A#/Bb");
            specialAB2.setToggleGroup(noteScale2);
            specialAB2.setFont(defaultFont);
            specialAB2.setTranslateY(-100);
            
            RadioButton radioB2 = new RadioButton("B");
            radioB2.setToggleGroup(noteScale2);
            radioB2.setFont(defaultFont);
            radioB2.setTranslateY(-80);
            
            RadioButton radioC2 = new RadioButton("C");
            radioC2.setToggleGroup(noteScale2);
            radioC2.requestFocus();
            radioC2.setSelected(true);
            radioC2.setFont(boldedFont);
            radioC2.setTranslateY(-60);
            
            RadioButton specialCD2 = new RadioButton("C#/Db");
            specialCD2.setToggleGroup(noteScale2);
            specialCD2.setFont(defaultFont);
            specialCD2.setTranslateY(-40);
            
            RadioButton radioD2 = new RadioButton("D");
            radioD2.setToggleGroup(noteScale2);
            radioD2.setFont(defaultFont);
            radioD2.setTranslateY(-20);
            
            RadioButton specialDE2 = new RadioButton("D#/Eb");
            specialDE2.setToggleGroup(noteScale2);
            specialDE2.setFont(defaultFont);
            specialDE2.setTranslateY(0);
            
            RadioButton radioE2 = new RadioButton("E");
            radioE2.setToggleGroup(noteScale2);
            radioE2.setFont(defaultFont);
            radioE2.setTranslateY(20);
            
            RadioButton radioF2 = new RadioButton("F");
            radioF2.setToggleGroup(noteScale2);
            radioF2.setFont(defaultFont);
            radioF2.setTranslateY(40);
            
            RadioButton specialFG2 = new RadioButton("F#/Gb");
            specialFG2.setToggleGroup(noteScale2);
            specialFG2.setFont(defaultFont);
            specialFG2.setTranslateY(60);
            
            RadioButton radioG2 = new RadioButton("G");
            radioG2.setToggleGroup(noteScale2);
            radioG2.setFont(defaultFont);
            radioG2.setTranslateY(80);
            
            RadioButton specialGA2 = new RadioButton("G#/Ab");
            specialGA2.setToggleGroup(noteScale2);
            specialGA2.setFont(defaultFont);
            specialGA2.setTranslateY(100);
            
            RadioButton silent2 = new RadioButton("Silent");
            silent2.setToggleGroup(noteScale2);
            silent2.setFont(defaultFont);
            silent2.setTranslateY(120);
            
            Group notes2 = new Group(radioA2,specialAB2,radioB2,radioC2,specialCD2,radioD2,specialDE2,radioE2,radioF2,specialFG2,radioG2,specialGA2,silent2);
            
            //Third ToggleGroup for the third list of radials
            final ToggleGroup noteScale3 = new ToggleGroup();
            
            //Radial list in question down below
            RadioButton radioA3 = new RadioButton("A");
            radioA3.setToggleGroup(noteScale3);
            radioA3.setFont(defaultFont);
            radioA3.setTranslateY(-120);
            
            RadioButton specialAB3 = new RadioButton("A#/Bb");
            specialAB3.setToggleGroup(noteScale3);
            specialAB3.setFont(defaultFont);
            specialAB3.setTranslateY(-100);
            
            RadioButton radioB3 = new RadioButton("B");
            radioB3.setToggleGroup(noteScale3);
            radioB3.setFont(defaultFont);
            radioB3.setTranslateY(-80);
            
            RadioButton radioC3 = new RadioButton("C");
            radioC3.setToggleGroup(noteScale3);
            radioC3.requestFocus();
            radioC3.setSelected(true);
            radioC3.setFont(boldedFont);
            radioC3.setTranslateY(-60);
            
            RadioButton specialCD3 = new RadioButton("C#/Db");
            specialCD3.setToggleGroup(noteScale3);
            specialCD3.setFont(defaultFont);
            specialCD3.setTranslateY(-40);
            
            RadioButton radioD3 = new RadioButton("D");
            radioD3.setToggleGroup(noteScale3);
            radioD3.setFont(defaultFont);
            radioD3.setTranslateY(-20);
            
            RadioButton specialDE3 = new RadioButton("D#/Eb");
            specialDE3.setToggleGroup(noteScale3);
            specialDE3.setFont(defaultFont);
            specialDE3.setTranslateY(0);
            
            RadioButton radioE3 = new RadioButton("E");
            radioE3.setToggleGroup(noteScale3);
            radioE3.setFont(defaultFont);
            radioE3.setTranslateY(20);
            
            RadioButton radioF3 = new RadioButton("F");
            radioF3.setToggleGroup(noteScale3);
            radioF3.setFont(defaultFont);
            radioF3.setTranslateY(40);
            
            RadioButton specialFG3 = new RadioButton("F#/Gb");
            specialFG3.setToggleGroup(noteScale3);
            specialFG3.setFont(defaultFont);
            specialFG3.setTranslateY(60);
            
            RadioButton radioG3 = new RadioButton("G");
            radioG3.setToggleGroup(noteScale3);
            radioG3.setFont(defaultFont);
            radioG3.setTranslateY(80);
            
            RadioButton specialGA3 = new RadioButton("G#/Ab");
            specialGA3.setToggleGroup(noteScale3);
            specialGA3.setFont(defaultFont);
            specialGA3.setTranslateY(100);
            
            RadioButton silent3 = new RadioButton("Silent");
            silent3.setToggleGroup(noteScale3);
            silent3.setFont(defaultFont);
            silent3.setTranslateY(120);
            
            //Grouping all radial buttons in one efficient group
            Group notes3 = new Group(radioA3,specialAB3,radioB3,radioC3,specialCD3,radioD3,specialDE3,radioE3,radioF3,specialFG3,radioG3,specialGA3,silent3);
            //Creating a textField for the user to input the length of the note.
            TextField noteLength = new TextField();
            
            //Adding in text to tell user what to do
            Text noteLengthDesc = new Text("Enter how long (in milliseconds) you want your note to be:");
            noteLengthDesc.setTextAlignment(LEFT);
            noteLengthDesc.setFont(Font.font("Calibri",FontWeight.BOLD, 11));
            noteLengthDesc.setFill(Color.WHITE);
            noteLengthDesc.setTranslateX(-150);
            
            //Creating a spinner for the octave value
            Spinner chooseOctave = new Spinner(1, 7, 1);
            Text chooseOctaveLabel = new Text("Choose the octave for your notes:");
            chooseOctaveLabel.setTextAlignment(LEFT);
            chooseOctaveLabel.setFont(defaultFont);
            
            //Creating mote spinners for the instrument values of each note
            
            Spinner instrumentValue1 = new Spinner(0,127,0);
            Spinner instrumentValue2 = new Spinner(0,127,0);
            Spinner instrumentValue3 = new Spinner(0,127,0);
            Text instrumentSpinnersLabel = new Text("Choose the instruments you want to use.\n(0 to 127)\n3 notes means 3 instruments.");
            instrumentSpinnersLabel.setFont(Font.font("Calibri",11));
            Text instrument1Label = new Text("Instrument for note 1:");
            instrument1Label.setFont(defaultFont);
            Text instrument2Label = new Text("Instrument for note 2:");
            instrument2Label.setFont(defaultFont);
            Text instrument3Label = new Text("Instrument for note 3:");
            instrument3Label.setFont(defaultFont);
            
            //Creating a VBox for the spinners and their labels
            VBox spinnerArea = new VBox();
            spinnerArea.getChildren().add(chooseOctaveLabel);
            spinnerArea.getChildren().add(chooseOctave);
            spinnerArea.getChildren().add(instrumentSpinnersLabel);
            spinnerArea.getChildren().add(instrumentValue1);
            spinnerArea.getChildren().add(instrument1Label);
            spinnerArea.getChildren().add(instrumentValue2);
            spinnerArea.getChildren().add(instrument2Label);
            spinnerArea.getChildren().add(instrumentValue3);
            spinnerArea.getChildren().add(instrument3Label);
            spinnerArea.setPadding(new Insets(20,20,20,20));
            spinnerArea.setSpacing(20);
            instrument1Label.setTranslateY(-60);
            instrument2Label.setTranslateY(-60);
            instrument3Label.setTranslateY(-60);            
            //Setting up a HBox for the text and textField
            HBox noteLengthPrompt = new HBox();
            noteLengthPrompt.setPadding(new Insets(15,12,15,12));
            noteLengthPrompt.setSpacing(10);
            noteLengthPrompt.setStyle("-fx-background-color: steelblue;");
            noteLengthPrompt.getChildren().add(noteLength);
            noteLengthPrompt.getChildren().add(noteLengthDesc);
            
            //Adding in a label for the note lists
            Text noteListLabel = new Text("Select which notes you want to add and\nwhat pitch you want them to be:\nleft list is note 1,\nmiddle list is note 2,\nand right list is note 3\n'Silent' means note is muted!");
            noteListLabel.setTextAlignment(LEFT);
            noteListLabel.setTranslateX(200);
            noteListLabel.setTranslateY(-80);
            noteListLabel.setFont(defaultFont);
            
            //Setting up a filter for the textfield with a TextFormatter and UnaryOperator combo!
            
            //UnaryOperator
            
            UnaryOperator<Change> integerFilter = (Change change) ->{
            String newText = change.getControlNewText();
            if (newText.matches("\\d*")){
                return change;
            }
            return null;
            };
            
            //TextFormatter using the UnaryOperator
            noteLength.setTextFormatter(new TextFormatter<>(new IntegerStringConverter(), 0, integerFilter));
            noteLength.setTranslateX(250);
            
            //Setting up the root group
            BorderPane root = new BorderPane();
            
            //Adding VBoxes for radio button lists
            VBox noteList1 = new VBox();
            
            //Adding note radio buttons and the description text label to VBoxes
            noteList1.getChildren().add(notes1);
            noteList1.setPadding(new Insets(0));
            noteList1.setSpacing(5);
            noteList1.setTranslateX(200);
            
            VBox noteList2 = new VBox();
            noteList2.getChildren().add(notes2);
            noteList2.setPadding(new Insets(0));
            noteList2.setSpacing(5);
            noteList2.setTranslateX(250);
            
            VBox noteList3 = new VBox();
            noteList3.getChildren().add(notes3);
            noteList3.setPadding(new Insets(0));
            noteList3.setSpacing(5);
            noteList3.setTranslateX(300);
            
            //Making a group to contain the noteLists
            Group noteParams = new Group(noteList1,noteList2,noteList3,noteListLabel);
            
            //Adding in a confirmatory button
            Button noteAdd = new Button("Click to add your selected notes");
            noteAdd.setTranslateY(100);
            
            //Adding an eventHandler for when the noteAdd button is clicked
            EventHandler<ActionEvent> addNotes = (ActionEvent e) -> {
                
            //Turning the text in the textfield into an integer
            int currNoteLength = Integer.parseInt(noteLength.getText());
            int noteLetterPitch = 0;
            //Grabbing what radiobutton from the noteScale toggle group is selected
            RadioButton selectedNotePitch1 = (RadioButton) noteScale1.getSelectedToggle();
            RadioButton selectedNotePitch2 = (RadioButton) noteScale2.getSelectedToggle();
            RadioButton selectedNotePitch3 = (RadioButton) noteScale3.getSelectedToggle();
            //Getting the text from the selected radio button
            String currNotePitch1 = selectedNotePitch1.getText();
            String currNotePitch2 = selectedNotePitch2.getText();
            String currNotePitch3 = selectedNotePitch3.getText();
            //Setting as for loop to add the letter pitch to the notepitch and then add the note parameters for each channel in that order.
            for(int i=0; i<3; i++){
                if (i==0){
                    if (null!=currNotePitch1) {
                        //Using a switch to change the noteLetterPitch value depending on what the currNotePitch for that channel is
                            switch (currNotePitch1) {
                                case "A":
                                    noteLetterPitch = 0;
                                    break;
                                case "A#/Bb":
                                    noteLetterPitch = 1;
                                    break;
                                case "B":
                                    noteLetterPitch = 2;
                                    break;
                                case "B#/Cb":
                                    noteLetterPitch = 3;
                                    break;
                                case "C":
                                    noteLetterPitch = 4;
                                    break;
                                case "C#/Db":
                                    noteLetterPitch = 5;
                                    break;
                                case "D":
                                    noteLetterPitch = 6;
                                    break;
                                case "D#/Eb":
                                    noteLetterPitch = 7;
                                    break;
                                case "E":
                                    noteLetterPitch = 8;
                                    break;
                                case "F":
                                    noteLetterPitch = 9;
                                    break;
                                case "F#/Gb":
                                    noteLetterPitch = 10;
                                    break;
                                case "G":
                                    noteLetterPitch = 11;
                                    break;
                                case "Silent":
                                    noteLetterPitch = 12;
                                    break;
                            }
                        }
                    //Adding each important value to their respective ArrayLists (time, tone, instrument, and octave)
                        toneListCh1.add(noteLetterPitch);
                        instrumentList1.add((Integer) instrumentValue1.getValue());
                        timeList.add(currNoteLength);
                        octaveList.add((Integer) chooseOctave.getValue());
                    }
                if (i==1){
                    if (null!=currNotePitch2) {
                            switch (currNotePitch2) {
                                case "A":
                                    noteLetterPitch = 0;
                                    break;
                                case "A#/Bb":
                                    noteLetterPitch = 1;
                                    break;
                                case "B":
                                    noteLetterPitch = 2;
                                    break;
                                case "B#/Cb":
                                    noteLetterPitch = 3;
                                    break;
                                case "C":
                                    noteLetterPitch = 4;
                                    break;
                                case "C#/Db":
                                    noteLetterPitch = 5;
                                    break;
                                case "D":
                                    noteLetterPitch = 6;
                                    break;
                                case "D#/Eb":
                                    noteLetterPitch = 7;
                                    break;
                                case "E":
                                    noteLetterPitch = 8;
                                    break;
                                case "F":
                                    noteLetterPitch = 9;
                                    break;
                                case "F#/Gb":
                                    noteLetterPitch = 10;
                                    break;
                                case "G":
                                    noteLetterPitch = 11;
                                    break;
                                case "Silent":
                                    noteLetterPitch = 12;
                                    break;
                        }
                            
                    }
                    toneListCh2.add(noteLetterPitch);
                    instrumentList2.add((Integer) instrumentValue2.getValue());
                    timeList.add(currNoteLength);
                    octaveList.add((Integer) chooseOctave.getValue());
                }
            if (i==2){
                if (null!=currNotePitch3) { 
                            switch (currNotePitch3) {
                                case "A":
                                    noteLetterPitch = 0;
                                    break;
                                case "A#/Bb":
                                    noteLetterPitch = 1;
                                    break;
                                case "B":
                                    noteLetterPitch = 2;
                                    break;
                                case "B#/Cb":
                                    noteLetterPitch = 3;
                                    break;
                                case "C":
                                    noteLetterPitch = 4;
                                    break;
                                case "C#/Db":
                                    noteLetterPitch = 5;
                                    break;
                                case "D":
                                    noteLetterPitch = 6;
                                    break;
                                case "D#/Eb":
                                    noteLetterPitch = 7;
                                    break;
                                case "E":
                                    noteLetterPitch = 8;
                                    break;
                                case "F":
                                    noteLetterPitch = 9;
                                    break;
                                case "F#/Gb":
                                    noteLetterPitch = 10;
                                    break;
                                case "G":
                                    noteLetterPitch = 11;
                                    break;
                                case "Silent":
                                    noteLetterPitch = 12;
                                    break;
                    }
                }
                toneListCh3.add(noteLetterPitch);
                instrumentList3.add((Integer) instrumentValue3.getValue());
                timeList.add(currNoteLength);
                octaveList.add((Integer) chooseOctave.getValue());
            }
        }
    };
            noteAdd.setOnAction(addNotes);
            
            //Adding a button to call the play method for all asdded notes.
            Button playButton = new Button("Click to play your song!");
            playButton.setTranslateY(300);
            
            //EventHandler calls the method
            EventHandler<ActionEvent> playNotes = (ActionEvent e) -> {
                Play.playSong(toneListCh1, toneListCh2, toneListCh3, timeList, octaveList, instrumentList1, instrumentList2, instrumentList3);
            };
            
            //Setting EventHandler to the playButton
            playButton.setOnAction(playNotes);
            
            //Addingn a button to undo the most recently added notes
            Button undoButton = new Button("Click to undo your most recent notes!");
            undoButton.setTranslateY(200);
            
            //EventHandle removes final entry in each arraylist because the final index of an arraylist is equal to 'arrayList.size-1'
            EventHandler<ActionEvent> undoNotes = (ActionEvent e) -> {
                toneListCh1.remove(toneListCh1.size()-1);
                toneListCh2.remove(toneListCh2.size()-1);
                toneListCh3.remove(toneListCh3.size()-1);
                octaveList.remove(octaveList.size()-1);
                instrumentList1.remove(instrumentList1.size()-1);
                instrumentList2.remove(instrumentList2.size()-1);
                instrumentList3.remove(instrumentList3.size()-1);
            };
            
            //Setting eventHandler to undoButton
            undoButton.setOnAction(undoNotes);
            
            //Adding a group to move the buttons as one object for efficiency
            Group buttons = new Group(noteAdd, playButton,undoButton);
            buttons.setTranslateY(100);
            
            //Setting each important area to separate regions of the borderPane
            root.setTop(noteLengthPrompt);
            root.setCenter(noteParams);
            root.setRight(buttons);
            root.setStyle("-fx-background-color: grey;");
            root.setLeft(spinnerArea);
            BorderPane.setMargin(root, new Insets(25));
            Scene noteParam = new Scene(root, 700, 500);
            stage.setTitle("Adding & Playing Notes");
            stage.setScene(noteParam);
            stage.show();
    }
    public static void main(String[] args) {
        launch();
    }
}