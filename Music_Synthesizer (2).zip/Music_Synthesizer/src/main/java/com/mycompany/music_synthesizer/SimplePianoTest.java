package com.mycompany.music_synthesizer;

public class SimplePianoTest {
    public static void main(String[] args) {
        Piano piano = new Piano();
        
        piano.changeAllInstrument(0); //Changes instrument back
        //Play a sequence of piano notes 57 59 60 62 64 65 67  A B C D E F G
        //Silent:0 A:21 A#:22 B:23 C:24 C#:25 D:26 D#:27 F:28 F#:29 G:30 G#:31
        //Speicial notes A#:58 C#:61 D#:63 F#:66 G#68
        piano.playNote(21, 2000,0); // A0
        piano.playNote(22, 2000,1); // A#
        piano.playNote(21, 2000,2); // A2
        piano.playNote(21, 2000,3); // A3
        piano.playNote(21, 2000,4); // A4 (Note, Time in ms)

        
        //Following is an example of getting the notes to stop outside of one script. Which may reduce lag
        piano.changeAllInstrument(46); //Changes instrument to whatever 46 is
        piano.unlimitedNote(67,0,0); //(note,channel)
        
        try {Thread.sleep(500);} catch (InterruptedException e){}
        
        piano.stopNote(67,0,0);//stops the note at (note,channel)
        
        
        //The following will showcase threading and play a c major
        
        piano.unlimitedNote(60,1,0); 
        piano.unlimitedNote(64,2,1); //(note octave channel)
        piano.unlimitedNote(67,3,2);
        try {Thread.sleep(1500);} catch (InterruptedException e){}
        piano.stopNote(60,1,0);
        try {Thread.sleep(1500);} catch (InterruptedException e){}//I want to slowly take each note off
        piano.stopNote(64,2,1);
        try {Thread.sleep(1500);} catch (InterruptedException e){}
        piano.stopNote(67,3,2);
    
    
    //execution time should be 8.7s
    piano.close(); // Close the synthesizer when done
    }
    

}