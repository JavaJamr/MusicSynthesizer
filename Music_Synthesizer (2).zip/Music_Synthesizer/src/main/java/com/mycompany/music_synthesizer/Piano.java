//If this suddenlt stops working clean the build (Hammer and Brush)
package com.mycompany.music_synthesizer;

import javax.sound.midi.*;

public class Piano {
    private Synthesizer synth; //Needs somewhere to make song
    private MidiChannel[] channels; //Needs a channel to play song
    
    
    
    public Piano() {//defines this as a function of the class that should be called to setup the piano
        try {//It won't run outside of a try catch
            synth = MidiSystem.getSynthesizer();
            synth.open();//Acticates the synthesizer
            channels = synth.getChannels();
        } catch (MidiUnavailableException e) 
{}} 
    public void changeAllInstrument(int instrument){
        channels[0].programChange(instrument); //0 by default
        channels[1].programChange(instrument); //0 by default
        channels[2].programChange(instrument); //0 by default
        channels[3].programChange(instrument); //0 by default
    }
    public void changeInstrument0(int instrument){channels[0].programChange(instrument);}
    public void changeInstrument1(int instrument){channels[1].programChange(instrument);}
    public void changeInstrument2(int instrument){channels[2].programChange(instrument);}
    public void changeInstrument3(int instrument){channels[3].programChange(instrument);}
    
    public void playNote(int note, int time,int octave) {//Will play an single note
        octave=octave*12;
        note=note+octave;
        if (channels != null && channels[0] != null) {
            channels[0].noteOn(note, 80); // Play note with velocity (We can set Velocity later)
            try {
                Thread.sleep(time); // Hold the note for the given duration
                } catch (InterruptedException e){}
            
            channels[0].noteOff(note); // Stop the note
}}
        
    public void unlimitedNote(int note, int octave, int channel)//Will play infinite length note (Can be mult-layered)

    {
    octave=octave*12;
    note=note+octave;
    channels[channel].noteOn(note, 80);
    }
    public void stopNote(int note,int octave,int channel)//Ideally used to turn off the infinite length note (Should reduce stuttering)

    {
    octave=octave*12;
    note=note+octave;
        channels[channel].noteOff(note);
    }
    
    public void close() {
        if (synth != null) {
            synth.close();//deactivates the synthesizer
}}} 
