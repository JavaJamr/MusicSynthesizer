package com.mycompany.music_synthesizer;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javax.sound.midi.*;

public class toneGen extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button("Play Piano Note");
        btn.setOnAction(this::playNote);
        
        StackPane root = new StackPane();
        root.getChildren().add(btn);
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("MIDI Piano");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private void playNote(ActionEvent event) {
        try {
            Synthesizer synth = MidiSystem.getSynthesizer();
            synth.open();
            MidiChannel[] channels = synth.getChannels();
            
            if (channels.length > 0) {
                channels[0].noteOn(60, 80); // Middle C (C4)60,80 (Velocity,Pitch)
                Thread.sleep(10000); // Hold for 10s (doesn't seem to really work as if these were ms but oh well)
                channels[0].noteOff(60); //Takes finger off the selected note
            }
            
            synth.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}