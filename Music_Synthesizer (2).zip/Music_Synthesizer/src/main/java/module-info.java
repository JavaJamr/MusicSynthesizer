module com.mycompany.music_synthesizer {
    requires javafx.controls;
    requires javafx.base;
    requires javafx.graphics;
    requires java.desktop;
    exports com.mycompany.music_synthesizer;
}
